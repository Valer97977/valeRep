package com.betacom.bec.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.betacom.bec.services.interfaces.ProdottoServices;
import com.betacom.bec.dto.ProdottoDTO;
import com.betacom.bec.request.ProdottoReq;
import com.betacom.bec.response.ResponseBase;
import com.betacom.bec.response.ResponseList;
import com.betacom.bec.response.ResponseObject;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/rest/prodotto")
public class ProdottoController {

    @Autowired
    private ProdottoServices prodottoS;

    @Autowired
    private org.slf4j.Logger log;

    @PostMapping("/create")
    public ResponseBase create(@RequestBody ProdottoReq req) {
        log.debug("create: " + req);
        ResponseBase r = new ResponseBase();
        try {
            prodottoS.create(req);
            r.setRc(true);
        } catch (Exception e) {
            log.error("Errore nella creazione del prodotto: ", e);
            r.setMsg(e.getMessage());
            r.setRc(false);
        }
        return r;
    }

    @PostMapping("/update")
    public ResponseBase update(@RequestBody ProdottoReq req) {
        log.debug("update: " + req);
        ResponseBase r = new ResponseBase();
        try {
            prodottoS.update(req);
            r.setRc(true);
        } catch (Exception e) {
            log.error("Errore nell'aggiornamento del prodotto: ", e);
            r.setMsg(e.getMessage());
            r.setRc(false);
        }
        return r;
    }

    @GetMapping("/listByCategoria/{categoria}")
    public ResponseList<ProdottoDTO> listByCategoria(@PathVariable String categoria) {
        log.debug("Lista prodotti per categoria: " + categoria);
        ResponseList<ProdottoDTO> r = new ResponseList<>();
        try {
            List<ProdottoDTO> prodotti = prodottoS.listByCategoria(categoria);
            r.setDati(prodotti);
            r.setRc(true);
        } catch (Exception e) {
            log.error("Errore nel recupero dei prodotti per categoria: ", e);
            r.setMsg(e.getMessage());
            r.setRc(false);
        }
        return r;
    }

    @PostMapping("/remove")
    public ResponseBase remove(@RequestBody ProdottoReq req) {
        log.debug("delete: " + req);
        ResponseBase r = new ResponseBase();
        try {
            prodottoS.removeProdotto(req);
            r.setRc(true);
        } catch (Exception e) {
            log.error("Errore nella rimozione del prodotto: ", e);
            r.setMsg(e.getMessage());
            r.setRc(false);
        }
        return r;
    }

    @GetMapping("/{id}")
    public ResponseObject<ProdottoDTO> getProdottoById(@PathVariable Integer id) {
        log.debug("Recupero prodotto con ID: " + id);
        ResponseObject<ProdottoDTO> r = new ResponseObject<>();
        try {
            ProdottoDTO prodotto = prodottoS.findById2(id);
            r.setDati(prodotto);
            r.setRc(true);
        } catch (Exception e) {
            log.error("Errore nel recupero del prodotto con ID: " + id, e);
            r.setRc(false);
            r.setMsg("Si è verificato un errore: " + e.getMessage());
        }
        return r;
    }

    @GetMapping("/list")
    public ResponseList<ProdottoDTO> listProdotti() {
        log.debug("Recupero lista di tutti i prodotti");
        ResponseList<ProdottoDTO> r = new ResponseList<>();
        try {
            List<ProdottoDTO> prodotti = prodottoS.listProdotti();
            r.setDati(prodotti);
            r.setRc(true);
        } catch (Exception e) {
            log.error("Errore nel recupero della lista prodotti: ", e);
            r.setMsg(e.getMessage());
            r.setRc(false);
        }
        return r;
    }

    @GetMapping("/find/{id}")
    public ResponseObject<ProdottoDTO> findById(@PathVariable int id) {
        log.debug("Ricerca prodotto con ID: " + id);
        ResponseObject<ProdottoDTO> r = new ResponseObject<>();
        try {
            Optional<ProdottoDTO> prodottoOpt = prodottoS.findById(id);
            if (prodottoOpt.isPresent()) {
                r.setDati(prodottoOpt.get());
                r.setRc(true);
            } else {
                r.setRc(false);
                r.setMsg("Prodotto non trovato.");
            }
        } catch (Exception e) {
            log.error("Errore nella ricerca del prodotto: ", e);
            r.setRc(false);
            r.setMsg("Errore durante la ricerca del prodotto: " + e.getMessage());
        }
        return r;
    }
}
