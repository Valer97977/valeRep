package com.betacom.bec.utils;

public enum Roles {
 ADMIN,
 USER,
 ALTRI
	
}
